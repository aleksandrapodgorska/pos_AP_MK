var searchData=
[
  ['read_5fand_5fstore_5fdata_0',['read_and_store_data',['../namespaceodb__sql.html#ac818cb82c69835792141fde262b02c91',1,'odb_sql']]]
];
