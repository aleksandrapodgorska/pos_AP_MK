var searchData=
[
  ['odb_5fsql_0',['odb_sql',['../namespaceodb__sql.html',1,'']]],
  ['odb_5fsql_2epy_1',['odb_sql.py',['../odb__sql_8py.html',1,'']]]
];
